from flask import Flask, render_template, jsonify, request
import base64
import cv2
import numpy as np
from pyzbar.pyzbar import decode
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Function to read barcode using pyzbar
def read_barcode(image):
    # Convert the OpenCV image (BGR) to grayscale
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Use pyzbar to detect and decode barcodes
    barcodes = decode(gray_image)
    
    # If barcodes are found, return the decoded data (assuming one barcode per image for simplicity)
    if barcodes:
        return barcodes[0].data.decode('utf-8')  # Assuming UTF-8 encoding for barcode data
    else:
        return None  # Return None if no barcode is detected

# Function to perform check-in
def check_in(index_number):
    conn = sqlite3.connect('library_attendance.db')
    c = conn.cursor()
    c.execute("INSERT INTO attendance (index_number, checkin_time) VALUES (?, ?)", (index_number, datetime.now()))
    conn.commit()
    conn.close()

# Function to perform check-out
def check_out(index_number):
    conn = sqlite3.connect('library_attendance.db')
    c = conn.cursor()
    c.execute("UPDATE attendance SET checkout_time = ? WHERE index_number = ? AND checkout_time IS NULL", (datetime.now(), index_number))
    conn.commit()
    conn.close()

# Route for home page
@app.route('/')
def home():
    return render_template('home.html')

# Route for the check-in page
@app.route('/checkin')
def checkin():
    return render_template('checkin.html')

# Route for handling barcode scanning for check-in
@app.route('/scan_checkin', methods=['POST'])
def scan_checkin():
    data = request.json['image']
    img_str = base64.b64decode(data.split(',')[1])
    np_arr = np.frombuffer(img_str, np.uint8)
    image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    
    index_number = read_barcode(image)
    if index_number:
        conn = sqlite3.connect('library_attendance.db')
        c = conn.cursor()
        c.execute("SELECT * FROM attendance WHERE index_number = ? AND checkout_time IS NULL", (index_number,))
        record = c.fetchone()
        
        if record:
            return jsonify({'message': f"Already checked in: {index_number}"}), 400
        
        check_in(index_number)
        return jsonify({'message': f"Checked in: {index_number}"})
    else:
        return jsonify({'message': 'No barcode detected. Please try again.'}), 400

# Route for the check-out page
@app.route('/checkout')
def checkout():
    return render_template('checkout.html')

# Route for handling barcode scanning for check-out
@app.route('/scan_checkout', methods=['POST'])
def scan_checkout():
    data = request.json['image']
    img_str = base64.b64decode(data.split(',')[1])
    np_arr = np.frombuffer(img_str, np.uint8)
    image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    
    index_number = read_barcode(image)
    if index_number:
        conn = sqlite3.connect('library_attendance.db')
        c = conn.cursor()
        c.execute("SELECT * FROM attendance WHERE index_number = ? AND checkout_time IS NULL", (index_number,))
        record = c.fetchone()
        
        if not record:
            return jsonify({'message': f"No active check-in found for {index_number}. Please check in first."}), 400
        
        check_out(index_number)
        return jsonify({'message': f"Checked out: {index_number}"}), 200
    else:
        return jsonify({'message': 'No barcode detected. Please try again.'}), 400

if __name__ == '__main__':
    app.run(debug=True)
