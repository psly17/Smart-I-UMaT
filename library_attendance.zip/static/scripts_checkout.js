document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('video');
    const message = document.getElementById('message');

    // Access the user's webcam
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
            scanBarcode();
        })
        .catch(error => {
            console.error('Error accessing the webcam:', error);
            message.textContent = 'Error accessing the webcam. Please try again.';
        });

    function scanBarcode() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        function captureFrame() {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

            const dataUrl = canvas.toDataURL('image/png');
            fetch('/scan_checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ image: dataUrl })
            })
            .then(response => response.json())
            .then(data => {
                message.textContent = data.message;
            })
            .catch(error => {
                console.error('Error:', error);
            });

            requestAnimationFrame(captureFrame);
        }

        captureFrame();
    }
});
